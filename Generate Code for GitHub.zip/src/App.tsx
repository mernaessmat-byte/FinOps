import Option2Dashboard from "./imports/Option2Dashboard";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Option2Dashboard />
    </div>
  );
}
