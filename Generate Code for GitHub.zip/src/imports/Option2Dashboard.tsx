import svgPaths from "./svg-ndxr7fkj0u";

const imgImg = "https://images.unsplash.com/photo-1701463387028-3947648f1337?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMGF2YXRhcnxlbnwxfHx8fDE3NjIxNzY3Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

function Div() {
  return (
    <div className="absolute bg-blue-600 left-[8px] rounded-[8px] size-[40px] top-[8px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[32px] leading-[normal] left-[4.09px] not-italic text-[24px] text-white top-[5px] w-[37px]">TA</p>
    </div>
  );
}

function Div1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[56px] left-[16px] top-[16px] w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div />
      <p className="absolute font-['Inter:Bold',sans-serif] font-['Inter:Regular',sans-serif] font-bold font-normal h-[28px] leading-[28px] left-[56px] not-italic text-[0px] text-[20px] text-black top-[14px] w-[202px]">
        <span className="text-slate-900">TASC</span>
        <span className="text-orange-500">{` FinOps`}</span>
      </p>
    </div>
  );
}

function Input() {
  return (
    <div className="absolute bg-slate-100 h-[36px] left-0 rounded-[8px] top-0 w-[223px]" data-name="input">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[36px] justify-center leading-[0] left-[40px] not-italic text-[#adaebc] text-[14px] top-[18px] translate-y-[-50%] w-[223px]">
        <p className="leading-[20px]">Search...</p>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_483)">
            <path d={svgPaths.p1d73a600} fill="var(--fill-0, #94A3B8)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_483">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[4px]" data-name="svg">
      <Frame />
    </div>
  );
}

function I() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[6px] w-[16px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg />
    </div>
  );
}

function Div2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[16px] top-[104px] w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Input />
      <I />
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <path d="M16 16H0V0H16V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p1efa7f0} fill="var(--fill-0, #F97316)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg1() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[2px] size-[16px] top-[4px]" data-name="svg">
      <Frame1 />
    </div>
  );
}

function I1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg1 />
    </div>
  );
}

function Div3() {
  return (
    <div className="absolute bg-orange-50 h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I1 />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-orange-500 top-[12px] w-[184px]">Dashboard</p>
    </div>
  );
}

function Li() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-0 w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div3 />
    </div>
  );
}

function Frame2() {
  return (
    <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_449)">
            <path d={svgPaths.p30d15700} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_449">
            <path d="M0 0H12V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg2() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-[4px] top-[4px] w-[12px]" data-name="svg">
      <Frame2 />
    </div>
  );
}

function I2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg2 />
    </div>
  );
}

function Div4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I2 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Invoices</p>
    </div>
  );
}

function Li1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[48px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div4 />
    </div>
  );
}

function Frame3() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_486)">
            <path d={svgPaths.p803d900} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_486">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg3() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[2px] size-[16px] top-[4px]" data-name="svg">
      <Frame3 />
    </div>
  );
}

function I3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg3 />
    </div>
  );
}

function Div5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I3 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Timesheets</p>
    </div>
  );
}

function Li2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[96px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div5 />
    </div>
  );
}

function Frame4() {
  return (
    <div className="h-[16px] relative shrink-0 w-[20px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_492)">
            <path d={svgPaths.p3ac12700} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_492">
            <path d="M0 0H20V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg4() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[20px]" data-name="svg">
      <Frame4 />
    </div>
  );
}

function I4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg4 />
    </div>
  );
}

function Div6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I4 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Dispatch</p>
    </div>
  );
}

function Li3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[144px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div6 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="h-[16px] relative shrink-0 w-[18px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 16">
        <g id="Frame">
          <path d="M18 16H0V0H18V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p3b0c80} fill="var(--fill-0, #475569)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg5() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-px top-[4px] w-[18px]" data-name="svg">
      <Frame5 />
    </div>
  );
}

function I5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg5 />
    </div>
  );
}

function Div7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I5 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Analytics</p>
    </div>
  );
}

function Li4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[192px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div7 />
    </div>
  );
}

function Ul() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[236px] left-0 top-[24px] w-[223px]" data-name="ul">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Li />
      <Li1 />
      <Li2 />
      <Li3 />
      <Li4 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_455)">
            <path d={svgPaths.p1a15c00} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_455">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg6() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[2px] size-[16px] top-[4px]" data-name="svg">
      <Frame9 />
    </div>
  );
}

function I6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg6 />
    </div>
  );
}

function Div8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I6 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Upload Documents</p>
    </div>
  );
}

function Li5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-0 w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div8 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_477)">
            <path d={svgPaths.p1899bb0} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_477">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg7() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[2px] size-[16px] top-[4px]" data-name="svg">
      <Frame10 />
    </div>
  );
}

function I7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg7 />
    </div>
  );
}

function Div9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I7 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Processing History</p>
    </div>
  );
}

function Li6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[48px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div9 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_446)">
            <path d={svgPaths.p21a72d80} fill="var(--fill-0, #475569)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_446">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg8() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-[2px] size-[16px] top-[4px]" data-name="svg">
      <Frame11 />
    </div>
  );
}

function I8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[10px] w-[20px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg8 />
    </div>
  );
}

function Div10() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 rounded-[8px] top-0 w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I8 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[normal] left-[44px] not-italic text-[16px] text-slate-600 top-[12px] w-[184px]">Settings</p>
    </div>
  );
}

function Li7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-[96px] w-[223px]" data-name="li">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div10 />
    </div>
  );
}

function Ul1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[140px] left-0 top-[316px] w-[223px]" data-name="ul">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Li5 />
      <Li6 />
      <Li7 />
    </div>
  );
}

function Nav() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[1163px] left-[16px] top-[164px] w-[223px]" data-name="nav">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[16px] leading-[16px] left-0 not-italic text-[12px] text-slate-400 top-0 tracking-[0.6px] w-[223px]">Main</p>
      <Ul />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[16px] leading-[16px] left-0 not-italic text-[12px] text-slate-400 top-[292px] tracking-[0.6px] w-[223px]">Shortcuts</p>
      <Ul1 />
    </div>
  );
}

function Img() {
  return (
    <div className="absolute left-0 pointer-events-none rounded-[9999px] size-[40px] top-0" data-name="img">
      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover rounded-[9999px] size-full" src={imgImg} />
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 rounded-[9999px]" />
    </div>
  );
}

function Div11() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[52px] top-[2px] w-[76.219px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-800 top-0 w-[77px]">John Smith</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 not-italic text-[12px] text-slate-500 top-[20px] w-[77px]">Admin</p>
    </div>
  );
}

function Div12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[40px] left-0 top-0 w-[128.219px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Img />
      <Div11 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <path d="M16 16H0V0H16V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p2244f2c0} fill="var(--fill-0, #64748B)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg9() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[2px]" data-name="svg">
      <Frame12 />
    </div>
  );
}

function I9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-0 top-[2px] w-[16px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg9 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[207px] top-[8px] w-[16px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <I9 />
    </div>
  );
}

function Div13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[40px] left-0 top-[17px] w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div12 />
      <Button />
    </div>
  );
}

function Div14() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] bottom-[16px] h-[57px] left-[16px] w-[223px]" data-name="div">
      <div aria-hidden="true" className="absolute border-[1px_0px_0px] border-slate-200 border-solid inset-0 pointer-events-none" />
      <Div13 />
    </div>
  );
}

function Aside() {
  return (
    <div className="absolute bg-white h-[1677px] left-0 top-0 w-[256px]" data-name="aside">
      <div aria-hidden="true" className="absolute border-[0px_1px_0px_0px] border-slate-200 border-solid inset-0 pointer-events-none" />
      <Div1 />
      <Div2 />
      <Nav />
      <Div14 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="h-[14px] relative shrink-0 w-[12.25px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_471)">
            <path d={svgPaths.p186a6100} fill="var(--fill-0, #F97316)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_471">
            <path d="M0 0H12.25V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg10() {
  return (
    <div className="absolute content-stretch flex h-[14px] items-center justify-center left-0 top-[2.75px] w-[12.25px]" data-name="svg">
      <Frame13 />
    </div>
  );
}

function I10() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[16px] top-[8px] w-[12.25px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg10 />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-0 rounded-[8px] top-0 w-[164.656px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I10 />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[103.25px] not-italic text-[14px] text-center text-orange-500 top-[9px] translate-x-[-50%] w-[134px]">New Automation</p>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-orange-500 h-[36px] left-[176.66px] rounded-[8px] top-0 w-[85.109px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[43px] not-italic text-[14px] text-center text-white top-[9px] translate-x-[-50%] w-[86px]">Create</p>
    </div>
  );
}

function Div15() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[858.23px] top-0 w-[261.766px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Button1 />
      <Button2 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[32px] top-[32px] w-[1120px]" data-name="header">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[36px] leading-[36px] left-0 not-italic text-[30px] text-slate-900 top-0 w-[346px]">TASC AI FinOps Central</p>
      <Div15 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Frame">
          <g clipPath="url(#clip0_1_480)">
            <path d={svgPaths.p271d8e00} fill="var(--fill-0, #2563EB)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_480">
            <path d="M0 0H20V20H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg11() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[20px] top-0" data-name="svg">
      <Frame14 />
    </div>
  );
}

function I11() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] left-[12px] size-[20px] top-[14px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg11 />
    </div>
  );
}

function Div16() {
  return (
    <div className="absolute bg-blue-50 h-[48px] left-0 rounded-[8px] top-0 w-[44px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I11 />
    </div>
  );
}

function Span() {
  return (
    <div className="absolute bg-green-100 h-[28px] left-[237.11px] rounded-[9999px] top-0 w-[70.219px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[35.5px] not-italic text-[14px] text-center text-green-600 top-[5px] translate-x-[-50%] w-[71px]">+12.5%</p>
    </div>
  );
}

function Div17() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[48px] left-[25px] top-[25px] w-[307.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div16 />
      <Span />
    </div>
  );
}

function Div18() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[64px] left-[25px] top-[89px] w-[307.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[44px] leading-[40px] left-0 not-italic text-[36px] text-slate-900 top-0 w-[308px]">2,847</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-500 top-[44px] w-[308px]">Processed Timesheets</p>
    </div>
  );
}

function Div19() {
  return (
    <div className="bg-white h-[178px] relative rounded-[16px] shrink-0 w-[357.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div17 />
      <Div18 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="h-[20px] relative shrink-0 w-[15px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 20">
        <g id="Frame">
          <g clipPath="url(#clip0_1_443)">
            <path d={svgPaths.p17c67800} fill="var(--fill-0, #F97316)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_443">
            <path d="M0 0H15V20H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg12() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-center left-0 top-0 w-[15px]" data-name="svg">
      <Frame15 />
    </div>
  );
}

function I12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[12px] top-[14px] w-[15px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg12 />
    </div>
  );
}

function Div20() {
  return (
    <div className="absolute bg-orange-50 h-[48px] left-0 rounded-[8px] top-0 w-[39px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I12 />
    </div>
  );
}

function Span1() {
  return (
    <div className="absolute bg-green-100 h-[28px] left-[242.91px] rounded-[9999px] top-0 w-[64.422px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[32.5px] not-italic text-[14px] text-center text-green-600 top-[5px] translate-x-[-50%] w-[65px]">+8.3%</p>
    </div>
  );
}

function Div21() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[48px] left-[25px] top-[25px] w-[307.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div20 />
      <Span1 />
    </div>
  );
}

function Div22() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[64px] left-[25px] top-[89px] w-[307.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[44px] leading-[40px] left-0 not-italic text-[36px] text-slate-900 top-0 w-[308px]">1,234</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-500 top-[44px] w-[308px]">Validated Invoices</p>
    </div>
  );
}

function Div23() {
  return (
    <div className="bg-white h-[178px] relative rounded-[16px] shrink-0 w-[357.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div21 />
      <Div22 />
    </div>
  );
}

function PaperPlaneTop() {
  return (
    <div className="absolute h-[20px] left-[calc(50%+0.094px)] top-[14px] translate-x-[-50%] w-[22.5px]" data-name="paper-plane-top">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23 20">
        <g clipPath="url(#clip0_1_452)" id="paper-plane-top">
          <path d={svgPaths.pb2b480} fill="var(--fill-0, #4F46E5)" id="Primary" />
        </g>
        <defs>
          <clipPath id="clip0_1_452">
            <rect fill="white" height="20" width="22.5" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Div24() {
  return (
    <div className="absolute bg-violet-50 h-[48px] left-0 rounded-[8px] top-0 w-[49px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <PaperPlaneTop />
    </div>
  );
}

function Span2() {
  return (
    <div className="absolute bg-green-100 h-[28px] left-[238.2px] rounded-[9999px] top-0 w-[69.141px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[35px] not-italic text-[14px] text-center text-green-600 top-[5px] translate-x-[-50%] w-[70px]">+15.7%</p>
    </div>
  );
}

function Div25() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[48px] left-[25px] top-[25px] w-[307.344px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div24 />
      <Span2 />
    </div>
  );
}

function Div26() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[64px] left-[25px] top-[89px] w-[307.344px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[44px] leading-[40px] left-0 not-italic text-[36px] text-slate-900 top-0 w-[308px]">892</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-500 top-[44px] w-[308px]">Dispatch Records</p>
    </div>
  );
}

function Div27() {
  return (
    <div className="bg-white h-[178px] relative rounded-[16px] shrink-0 w-[357.344px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div25 />
      <Div26 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0 w-full">
      <Div19 />
      <Div23 />
      <Div27 />
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-[4px] rounded-[6px] top-[4px] w-[42.031px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[6px]" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[21.5px] not-italic text-[14px] text-center text-slate-800 top-[5px] translate-x-[-50%] w-[43px]">7D</p>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-white h-[28px] left-[50.03px] rounded-[6px] top-[4px] w-[52.266px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[6px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[26.5px] not-italic text-[14px] text-center text-orange-500 top-[5px] translate-x-[-50%] w-[53px]">30D</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-[106.3px] rounded-[6px] top-[4px] w-[51.625px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[6px]" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[26px] not-italic text-[14px] text-center text-slate-800 top-[5px] translate-x-[-50%] w-[52px]">90D</p>
    </div>
  );
}

function Div28() {
  return (
    <div className="absolute bg-slate-100 h-[36px] left-[431.41px] rounded-[8px] top-0 w-[161.922px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Button3 />
      <Button4 />
      <Button5 />
    </div>
  );
}

function Div29() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[25px] top-[25px] w-[593.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[28px] left-0 not-italic text-[18px] text-slate-900 top-[4px] w-[250px]">Processing Volume</p>
      <Div28 />
    </div>
  );
}

function Frame26358() {
  return (
    <div className="absolute content-stretch flex flex-col font-['DM_Sans:Regular',sans-serif] font-normal h-[216.955px] items-start justify-between leading-[1.4] left-[25px] text-[#6d7175] text-[12px] top-[86.58px] tracking-[-0.36px] w-[26px]">
      <p className="h-[24.158px] relative shrink-0 w-[44.479px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        5K
      </p>
      <p className="h-[24.158px] relative shrink-0 w-[44.479px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        4K
      </p>
      <p className="h-[24.158px] relative shrink-0 w-[44.479px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        3K
      </p>
      <p className="h-[24.158px] relative shrink-0 w-[44.479px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        2K
      </p>
      <p className="h-[24.158px] relative shrink-0 w-[44.479px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        1K
      </p>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute h-[187.847px] left-[55.06px] top-[97.92px] w-[562.937px]">
      <div className="absolute bottom-0 left-0 right-0 top-[-0.27%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 563 189">
          <g id="Group 2">
            <line id="Line 14" stroke="var(--stroke-0, #858B93)" strokeDasharray="4 4" strokeOpacity="0.18" strokeWidth="0.5" x2="561.758" y1="0.25" y2="0.25" />
            <line id="Line 15" stroke="var(--stroke-0, #858B93)" strokeDasharray="4 4" strokeOpacity="0.18" strokeWidth="0.5" x1="1.14441e-05" x2="561.758" y1="94.7225" y2="94.7225" />
            <line id="Line 16" stroke="var(--stroke-0, #858B93)" strokeDasharray="4 4" strokeOpacity="0.18" strokeWidth="0.5" x1="1.14441e-05" x2="561.758" y1="188.097" y2="188.097" />
            <line id="Line 11" stroke="var(--stroke-0, #858B93)" strokeDasharray="4 4" strokeOpacity="0.18" strokeWidth="0.5" x1="0.589458" x2="562.348" y1="47.4863" y2="47.4863" />
            <line id="Line 12" stroke="var(--stroke-0, #858B93)" strokeDasharray="4 4" strokeOpacity="0.18" strokeWidth="0.5" x1="0.589458" x2="562.937" y1="141.959" y2="141.959" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute inset-[24.02%_5.54%_21.05%_10.45%]">
      <div className="absolute inset-[-1.02%_-0.37%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 545 201">
          <g id="Group 3">
            <path d={svgPaths.p26bedd00} id="Shape" stroke="var(--stroke-0, #F97316)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame26359() {
  return (
    <div className="absolute content-stretch flex font-['DM_Sans:Regular',sans-serif] font-normal h-[18.675px] items-start justify-between leading-[1.4] left-[57.42px] text-[#202223] text-[12px] text-nowrap top-[314.32px] tracking-[-0.36px] w-[556.759px] whitespace-pre">
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        01,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        03,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        05,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        07,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        09,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        11,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        13,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        15,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        17,Jul
      </p>
      <p className="relative shrink-0" style={{ fontVariationSettings: "'opsz' 14" }}>
        19,Jul
      </p>
    </div>
  );
}

function Frame26362() {
  return (
    <div className="absolute box-border content-stretch flex flex-col gap-[10px] items-start left-[calc(50%-174.54px)] p-[10px] top-[202.9px] translate-x-[-50%]">
      <div className="bg-orange-500 h-[24px] relative rounded-[20px] shrink-0 w-[24.358px]" data-name="Selector">
        <div aria-hidden="true" className="absolute border-4 border-solid border-white inset-0 pointer-events-none rounded-[20px] shadow-[0px_2.667px_2.667px_0px_rgba(50,50,71,0.06),0px_2.667px_5.333px_0px_rgba(50,50,71,0.06)]" />
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[calc(50%-174.54px)] top-[202.9px] translate-x-[-50%]">
      <Frame26362 />
    </div>
  );
}

function Group25902() {
  return (
    <div className="absolute contents left-[25px] top-[86px]">
      <Frame26358 />
      <Group2 />
      <Group3 />
      <Frame26359 />
      <Group6 />
    </div>
  );
}

function Div30() {
  return (
    <div className="bg-white h-[358px] relative rounded-[16px] shrink-0 w-[643.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div29 />
      <Group25902 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="h-[16px] relative shrink-0 w-[14px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 16">
        <g id="Frame">
          <path d="M14 16H0V0H14V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p7a1ad80} fill="var(--fill-0, #64748B)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg13() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[2px] w-[14px]" data-name="svg">
      <Frame16 />
    </div>
  );
}

function I13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-0 top-[2px] w-[14px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg13 />
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[388.67px] top-[2px] w-[14px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <I13 />
    </div>
  );
}

function Div31() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-[25px] top-[25px] w-[402.672px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[28px] left-0 not-italic text-[18px] text-slate-900 top-0 w-[226px]">Invoice Status Breakdown</p>
      <Button6 />
    </div>
  );
}

function Div32() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[256px] left-[25px] top-[69px] w-[402.672px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Frame1160445704() {
  return (
    <div className="[grid-area:1_/_1] box-border content-stretch flex flex-col items-center leading-[1.4] ml-[118.996px] mt-[80px] relative text-center text-nowrap w-[98px] whitespace-pre">
      <p className="font-['DM_Sans:Bold',sans-serif] font-bold relative shrink-0 text-[#202223] text-[16px] tracking-[-0.48px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        5,000
      </p>
      <p className="font-['DM_Sans:Medium',sans-serif] font-medium relative shrink-0 text-[#6d7175] text-[14px] tracking-[-0.42px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Invoice
      </p>
    </div>
  );
}

function Group25934() {
  return (
    <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative">
      <div className="[grid-area:1_/_1] font-['Graphie:Semi_Bold',sans-serif] leading-[1.4] ml-[46.5px] mt-0 not-italic relative text-[#202223] text-[0px] text-[12px] text-center text-nowrap tracking-[-0.36px] translate-x-[-50%] whitespace-pre">
        <p className="font-['DM_Sans:Regular',sans-serif] font-normal mb-0 text-[#6d7175]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Processing (20%)
        </p>
        <p className="font-['DM_Sans:Medium',sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
          857
        </p>
      </div>
      <div className="[grid-area:1_/_1] flex h-[calc(1px*((var(--transform-inner-width)*0.5)+(var(--transform-inner-height)*0.8660253882408142)))] items-center justify-center ml-[85.5px] mt-[14.938px] relative w-[calc(1px*((var(--transform-inner-height)*0.5)+(var(--transform-inner-width)*0.8660253882408142)))]" style={{ "--transform-inner-width": "17.984375", "--transform-inner-height": "19.203125" } as React.CSSProperties}>
        <div className="flex-none rotate-[150deg] scale-y-[-100%]">
          <div className="h-[19.203px] relative w-[17.992px]">
            <div className="absolute inset-[-2.22%_-1.45%_-0.96%_-2.58%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 20">
                <path d={svgPaths.p160d4000} id="Vector 3" stroke="var(--stroke-0, #2563EB)" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="[grid-area:1_/_1] font-['Graphie:Semi_Bold',sans-serif] leading-[1.4] ml-[38.5px] mt-[143px] not-italic relative text-[#202223] text-[0px] text-[12px] text-center text-nowrap tracking-[-0.36px] translate-x-[-50%] whitespace-pre">
        <p className="font-['DM_Sans:Regular',sans-serif] font-normal mb-0 text-[#6d7175]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Pending (20%)
        </p>
        <p className="font-['DM_Sans:Medium',sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
          1,124
        </p>
      </div>
      <div className="[grid-area:1_/_1] flex h-[calc(1px*((var(--transform-inner-width)*0.9942474961280823)+(var(--transform-inner-height)*0.10710717737674713)))] items-center justify-center ml-[63.073px] mt-[121.841px] relative w-[calc(1px*((var(--transform-inner-height)*0.9942474961280823)+(var(--transform-inner-width)*0.10710717737674713)))]" style={{ "--transform-inner-width": "17.984375", "--transform-inner-height": "19.203125" } as React.CSSProperties}>
        <div className="flex-none rotate-[96.149deg] scale-y-[-100%]">
          <div className="h-[19.203px] relative w-[17.992px]">
            <div className="absolute inset-[-2.22%_-1.45%_-0.96%_-2.58%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 20">
                <path d={svgPaths.p160d4000} id="Vector 7" stroke="var(--stroke-0, #FB923C)" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="[grid-area:1_/_1] font-['Graphie:Semi_Bold',sans-serif] leading-[1.4] ml-[320.499px] mt-[30px] not-italic relative text-[#202223] text-[0px] text-[12px] text-center text-nowrap tracking-[-0.36px] translate-x-[-50%] whitespace-pre">
        <p className="font-['DM_Sans:Regular',sans-serif] font-normal mb-0 text-[#6d7175]" style={{ fontVariationSettings: "'opsz' 14" }}>
          Approved (20%)
        </p>
        <p className="font-['DM_Sans:Medium',sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
          1,125
        </p>
      </div>
      <div className="[grid-area:1_/_1] flex h-[calc(1px*((var(--transform-inner-width)*0.5)+(var(--transform-inner-height)*0.8660253882408142)))] items-center justify-center ml-[247.995px] mt-[32px] relative w-[calc(1px*((var(--transform-inner-height)*0.5)+(var(--transform-inner-width)*0.8660253882408142)))]" style={{ "--transform-inner-width": "17.984375", "--transform-inner-height": "19.203125" } as React.CSSProperties}>
        <div className="flex-none rotate-[30deg]">
          <div className="h-[19.203px] relative w-[17.992px]">
            <div className="absolute inset-[-2.22%_-1.45%_-0.96%_-2.58%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 19 20">
                <path d={svgPaths.p160d4000} id="Vector 4" stroke="var(--stroke-0, #10B981)" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="[grid-area:1_/_1] font-['Graphie:Semi_Bold',sans-serif] leading-[1.4] ml-[305.998px] mt-[164px] not-italic relative text-[#202223] text-[0px] text-[12px] text-center text-nowrap tracking-[-0.36px] translate-x-[-50%] whitespace-pre">
        <p className="font-['DM_Sans:Regular',sans-serif] font-normal mb-0 text-[#6d7175]" style={{ fontVariationSettings: "'opsz' 14" }}>{`Rejected  (20%)`}</p>
        <p className="font-['DM_Sans:Medium',sans-serif] font-medium" style={{ fontVariationSettings: "'opsz' 14" }}>
          1,125
        </p>
      </div>
      <div className="[grid-area:1_/_1] flex h-[calc(1px*((var(--transform-inner-width)*0.5)+(var(--transform-inner-height)*0.8660253882408142)))] items-center justify-center ml-[221.499px] mt-[159.465px] relative w-[calc(1px*((var(--transform-inner-height)*0.5)+(var(--transform-inner-width)*0.8660253882408142)))]" style={{ "--transform-inner-width": "31.046875", "--transform-inner-height": "29.546875" } as React.CSSProperties}>
        <div className="flex-none rotate-[30deg]">
          <div className="h-[29.557px] relative w-[31.062px]">
            <div className="absolute inset-[-0.7%_-1.47%_-1.39%_-0.91%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 31">
                <path d={svgPaths.p11b36600} id="Vector 5" stroke="var(--stroke-0, #EF4444)" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Group60() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <div className="[grid-area:1_/_1] ml-[72.996px] mt-[5px] relative size-[197px]">
        <div className="absolute bottom-[12.34%] left-[71.57%] right-0 top-[15.49%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 56 143">
            <g id="Ellipse 1">
              <mask fill="white" id="path-1-inside-1_1_461">
                <path d={svgPaths.p1d7300} />
              </mask>
              <path d={svgPaths.p1d7300} fill="var(--fill-0, #10B981)" mask="url(#path-1-inside-1_1_461)" stroke="var(--stroke-0, white)" strokeWidth="2" />
            </g>
          </svg>
        </div>
      </div>
      <div className="[grid-area:1_/_1] ml-[72.996px] mt-[5px] relative size-[197px]">
        <div className="absolute bottom-0 left-[24.03%] right-[19.45%] top-[76.12%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 112 48">
            <g id="Ellipse 2">
              <mask fill="white" id="path-1-inside-1_1_417">
                <path d={svgPaths.p6b43170} />
              </mask>
              <path d={svgPaths.p6b43170} fill="var(--fill-0, #EF4444)" mask="url(#path-1-inside-1_1_417)" stroke="var(--stroke-0, white)" strokeWidth="2" />
            </g>
          </svg>
        </div>
      </div>
      <div className="[grid-area:1_/_1] ml-[72.996px] mt-[5px] relative size-[197px]">
        <div className="absolute bottom-[8.85%] left-0 right-[68.47%] top-[21.28%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 63 138">
            <g id="Ellipse 4">
              <mask fill="white" id="path-1-inside-1_1_495">
                <path d={svgPaths.p372fb6f0} />
              </mask>
              <path d={svgPaths.p372fb6f0} fill="var(--fill-0, #FB923C)" mask="url(#path-1-inside-1_1_495)" stroke="var(--stroke-0, white)" strokeWidth="2" />
            </g>
          </svg>
        </div>
      </div>
      <div className="[grid-area:1_/_1] ml-[72.996px] mt-[5px] relative size-[197px]">
        <div className="absolute bottom-[70.93%] left-[11.55%] right-[16.35%] top-0">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 143 58">
            <g id="Ellipse 3">
              <mask fill="white" id="path-1-inside-1_1_413">
                <path d={svgPaths.p5022d00} />
              </mask>
              <path d={svgPaths.p5022d00} fill="var(--fill-0, #2563EB)" mask="url(#path-1-inside-1_1_413)" stroke="var(--stroke-0, white)" strokeWidth="2" />
            </g>
          </svg>
        </div>
      </div>
      <Frame1160445704 />
      <Group25934 />
    </div>
  );
}

function Frame1160445702() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-[90px]">
      <div className="bg-blue-600 rounded-[4px] shrink-0 size-[16px]" />
      <p className="basis-0 font-['DM_Sans:Medium',sans-serif] font-medium grow leading-[1.4] min-h-px min-w-px relative shrink-0 text-[#202223] text-[14px] tracking-[-0.42px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Starter
      </p>
    </div>
  );
}

function Frame1160445701() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-[90px]">
      <div className="bg-emerald-500 rounded-[4px] shrink-0 size-[16px]" />
      <p className="basis-0 font-['DM_Sans:Medium',sans-serif] font-medium grow leading-[1.4] min-h-px min-w-px relative shrink-0 text-[#202223] text-[14px] tracking-[-0.42px]" style={{ fontVariationSettings: "'opsz' 14" }}>{`Approved `}</p>
    </div>
  );
}

function Frame1160445700() {
  return (
    <div className="basis-0 content-stretch flex gap-[8px] grow items-center min-h-px min-w-px relative shrink-0">
      <div className="bg-red-500 rounded-[4px] shrink-0 size-[16px]" />
      <p className="basis-0 font-['DM_Sans:Medium',sans-serif] font-medium grow leading-[1.4] min-h-px min-w-px relative shrink-0 text-[#202223] text-[14px] tracking-[-0.42px]" style={{ fontVariationSettings: "'opsz' 14" }}>{`Rejected `}</p>
    </div>
  );
}

function Frame27541() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[90px]">
      <Frame1160445700 />
    </div>
  );
}

function Frame1160445699() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0 w-[90px]">
      <div className="bg-orange-400 rounded-[4px] shrink-0 size-[16px]" />
      <p className="basis-0 font-['DM_Sans:Medium',sans-serif] font-medium grow leading-[1.4] min-h-px min-w-px relative shrink-0 text-[#202223] text-[14px] tracking-[-0.42px]" style={{ fontVariationSettings: "'opsz' 14" }}>
        Pending
      </p>
    </div>
  );
}

function Frame26398() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Frame1160445702 />
      <Frame1160445701 />
      <Frame27541 />
      <Frame1160445699 />
    </div>
  );
}

function Frame26400() {
  return (
    <div className="absolute content-stretch flex flex-col inset-[25.14%_7.07%_6.42%_5.01%] items-center justify-between">
      <Group60 />
      <Frame26398 />
    </div>
  );
}

function Div33() {
  return (
    <div className="bg-white h-[358px] relative rounded-[16px] shrink-0 w-[452.672px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div31 />
      <Div32 />
      <Frame26400 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <Div30 />
      <Div33 />
    </div>
  );
}

function Frame17() {
  return (
    <div className="h-[20px] relative shrink-0 w-[25px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 20">
        <g id="Frame">
          <path d="M25 20H0V0H25V20Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p2e07e700} fill="var(--fill-0, #64748B)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg14() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-center left-0 top-[3.5px] w-[25px]" data-name="svg">
      <Frame17 />
    </div>
  );
}

function I14() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-[11.5px] top-[10px] w-[25px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg14 />
    </div>
  );
}

function Div34() {
  return (
    <div className="absolute bg-slate-200 left-[237.5px] rounded-[9999px] size-[48px] top-[34px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I14 />
    </div>
  );
}

function P() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[34px] top-[94px] w-[455px]" data-name="p">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[205.23px] not-italic text-[14px] text-center text-slate-700 top-px translate-x-[-50%] w-[174px]">Drop files here or click to</p>
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[20px] left-[312.22px] not-italic text-[14px] text-center text-orange-500 top-px translate-x-[-50%] w-[51px]">browse</p>
    </div>
  );
}

function P1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[16px] left-[34px] top-[118px] w-[455px]" data-name="p">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[normal] left-[227.5px] not-italic text-[12px] text-center text-slate-500 top-0 translate-x-[-50%] w-[455px]">Supports PDF, DOC, XLS, CSV files up to 10MB</p>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-orange-500 h-[36px] left-[202.75px] rounded-[8px] top-[150px] w-[117.484px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[59px] not-italic text-[14px] text-center text-white top-[9px] translate-x-[-50%] w-[118px]">Select Files</p>
    </div>
  );
}

function Div35() {
  return (
    <div className="absolute bg-slate-50 h-[220px] left-0 rounded-[12px] top-[68px] w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-2 border-dashed border-slate-300 inset-0 pointer-events-none rounded-[12px]" />
      <Div34 />
      <P />
      <P1 />
      <Button7 />
    </div>
  );
}

function Div36() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[288px] left-0 top-0 w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[28px] left-0 not-italic text-[18px] text-slate-900 top-0 w-[523px]">Document Upload</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-500 top-[32px] w-[523px]">Drag and drop files or click to upload</p>
      <Div35 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Frame">
          <g clipPath="url(#clip0_1_408)">
            <path d={svgPaths.p1ca55f00} fill="var(--fill-0, #EF4444)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_408">
            <path d="M0 0H24V24H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg15() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[24px] top-[3px]" data-name="svg">
      <Frame18 />
    </div>
  );
}

function I15() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[32px] left-[12px] top-[12px] w-[24px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg15 />
    </div>
  );
}

function Div37() {
  return (
    <div className="absolute bg-green-500 h-[6px] left-0 rounded-[9999px] top-0 w-[378.578px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
    </div>
  );
}

function Div38() {
  return (
    <div className="absolute bg-slate-200 h-[6px] left-0 rounded-[9999px] top-[24px] w-[378.578px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <Div37 />
    </div>
  );
}

function Div39() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[30px] left-[52px] top-[13px] w-[378.578px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-800 top-0 w-[379px]">invoice_march_2024.pdf</p>
      <Div38 />
    </div>
  );
}

function Span3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[446.58px] top-[18px] w-[64.422px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-0 not-italic text-[14px] text-green-500 top-px w-[65px]">Complete</p>
    </div>
  );
}

function Div40() {
  return (
    <div className="absolute bg-slate-50 h-[56px] left-0 rounded-[8px] top-0 w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I15 />
      <Div39 />
      <Span3 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="h-[24px] relative shrink-0 w-[18px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 24">
        <g id="Frame">
          <g clipPath="url(#clip0_1_405)">
            <path d={svgPaths.p196ad800} fill="var(--fill-0, #16A34A)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_405">
            <path d="M0 0H18V24H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg16() {
  return (
    <div className="absolute content-stretch flex h-[24px] items-center justify-center left-0 top-[3px] w-[18px]" data-name="svg">
      <Frame19 />
    </div>
  );
}

function I16() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[32px] left-[12px] top-[12px] w-[18px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg16 />
    </div>
  );
}

function Div41() {
  return (
    <div className="absolute bg-amber-500 h-[6px] left-0 rounded-[9999px] top-0 w-[271.578px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
    </div>
  );
}

function Div42() {
  return (
    <div className="absolute bg-slate-200 h-[6px] left-0 rounded-[9999px] top-[24px] w-[417.828px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <Div41 />
    </div>
  );
}

function Div43() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[30px] left-[46px] top-[13px] w-[417.828px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-800 top-0 w-[418px]">timesheet_data.xlsx</p>
      <Div42 />
    </div>
  );
}

function Span4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[479.83px] top-[18px] w-[31.172px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-0 not-italic text-[14px] text-amber-500 top-px w-[32px]">65%</p>
    </div>
  );
}

function Div44() {
  return (
    <div className="absolute bg-slate-50 h-[56px] left-0 rounded-[8px] top-[68px] w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I16 />
      <Div43 />
      <Span4 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Frame">
          <g clipPath="url(#clip0_1_427)">
            <path d={svgPaths.p34c2c800} fill="var(--fill-0, #64748B)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_427">
            <path d="M0 0H24V24H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg17() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[24px] top-[3px]" data-name="svg">
      <Frame20 />
    </div>
  );
}

function I17() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[32px] left-[12px] top-[14px] w-[24px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg17 />
    </div>
  );
}

function Div45() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[52px] top-[12px] w-[459px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-800 top-0 w-[459px]">dispatch_orders.csv</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 not-italic text-[12px] text-slate-500 top-[20px] w-[459px]">Queued</p>
    </div>
  );
}

function Div46() {
  return (
    <div className="absolute bg-slate-50 h-[60px] left-0 rounded-[8px] top-[136px] w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I17 />
      <Div45 />
    </div>
  );
}

function Div47() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[196px] left-0 top-[68px] w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div40 />
      <Div44 />
      <Div46 />
    </div>
  );
}

function Div48() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[288px] left-[547px] top-0 w-[523px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[28px] left-0 not-italic text-[18px] text-slate-900 top-0 w-[523px]">Upload Queue</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[14px] text-slate-500 top-[32px] w-[523px]">{`Your uploaded invoices `}</p>
      <Div47 />
    </div>
  );
}

function Div49() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[288px] left-[25px] top-[25px] w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div36 />
      <Div48 />
    </div>
  );
}

function Div50() {
  return (
    <div className="bg-white h-[338px] relative rounded-[16px] shrink-0 w-full" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div49 />
    </div>
  );
}

function Div51() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[1065.28px] top-[4px] w-[54.719px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-0 not-italic text-[14px] text-orange-500 top-px w-[55px]">View All</p>
    </div>
  );
}

function Div52() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-0 top-0 w-[1120px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold h-[28px] leading-[28px] left-0 not-italic text-[20px] text-slate-900 top-0 w-[179px]">AI Modules Status</p>
      <Div51 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_463)">
            <path d={svgPaths.p803d900} fill="var(--fill-0, #2563EB)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_463">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg18() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[2px]" data-name="svg">
      <Frame21 />
    </div>
  );
}

function I18() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[10px] top-[12px] w-[16px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg18 />
    </div>
  );
}

function Div53() {
  return (
    <div className="absolute bg-blue-50 h-[44px] left-0 rounded-[8px] top-0 w-[36px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I18 />
    </div>
  );
}

function Div54() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-0 w-[149.875px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div53 />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[48px] not-italic text-[16px] text-slate-800 top-[10px] w-[103px]">AI Timesheet</p>
    </div>
  );
}

function Frame22() {
  return (
    <div className="relative shrink-0 size-[7.5px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
        <g id="Frame">
          <g clipPath="url(#clip0_1_474)">
            <path d={svgPaths.p87dc880} fill="var(--fill-0, #15803D)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_474">
            <path d="M0 0H7.5V7.5H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg19() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[7.5px] top-[3.75px]" data-name="svg">
      <Frame22 />
    </div>
  );
}

function I19() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[16px] left-[8px] top-[2px] w-[7.5px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg19 />
    </div>
  );
}

function Span5() {
  return (
    <div className="absolute bg-green-100 h-[20px] left-[264.3px] rounded-[9999px] top-[12px] w-[51.031px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I19 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[16px] leading-[normal] left-[19.5px] not-italic text-[12px] text-green-700 top-[2px] w-[37px]">Live</p>
    </div>
  );
}

function Div55() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-[21px] top-[21px] w-[315.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div54 />
      <Span5 />
    </div>
  );
}

function P2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[40px] left-[21px] top-[77px] w-[315.328px]" data-name="p">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-px w-[316px]">Automated timesheet processing and validation</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-[21px] w-[316px]">with AI-powered accuracy checks.</p>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-slate-100 h-[36px] left-[21px] rounded-[8px] top-[153px] w-[315.328px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[158px] not-italic text-[14px] text-center text-slate-700 top-[9px] translate-x-[-50%] w-[316px]">Open Module</p>
    </div>
  );
}

function Div56() {
  return (
    <div className="absolute bg-white h-[210px] left-0 rounded-[16px] top-0 w-[357.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div55 />
      <P2 />
      <Button8 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_424)">
            <path d={svgPaths.p30d15700} fill="var(--fill-0, #F97316)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_424">
            <path d="M0 0H12V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg20() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[2px] w-[12px]" data-name="svg">
      <Frame23 />
    </div>
  );
}

function I20() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[10px] top-[12px] w-[12px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg20 />
    </div>
  );
}

function Div57() {
  return (
    <div className="absolute bg-orange-50 h-[44px] left-0 rounded-[8px] top-0 w-[32px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <I20 />
    </div>
  );
}

function Div58() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-0 w-[134.391px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div57 />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[44px] not-italic text-[16px] text-slate-800 top-[10px] w-[91px]">AI Invoicing</p>
    </div>
  );
}

function Frame24() {
  return (
    <div className="relative shrink-0 size-[7.5px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
        <g id="Frame">
          <g clipPath="url(#clip0_1_474)">
            <path d={svgPaths.p87dc880} fill="var(--fill-0, #15803D)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_474">
            <path d="M0 0H7.5V7.5H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg21() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[7.5px] top-[3.75px]" data-name="svg">
      <Frame24 />
    </div>
  );
}

function I21() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[16px] left-[8px] top-[2px] w-[7.5px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg21 />
    </div>
  );
}

function Span6() {
  return (
    <div className="absolute bg-green-100 h-[20px] left-[264.3px] rounded-[9999px] top-[12px] w-[51.031px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I21 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[16px] leading-[normal] left-[19.5px] not-italic text-[12px] text-green-700 top-[2px] w-[37px]">Live</p>
    </div>
  );
}

function Div59() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-[21px] top-[21px] w-[315.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div58 />
      <Span6 />
    </div>
  );
}

function P3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[60px] left-[21px] top-[77px] w-[315.328px]" data-name="p">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-px w-[316px]">Smart invoice generation, validation, and</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-[21px] w-[316px]">approval workflows powered by machine</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-[41px] w-[316px]">learning.</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-slate-100 h-[36px] left-[21px] rounded-[8px] top-[153px] w-[315.328px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[158px] not-italic text-[14px] text-center text-slate-700 top-[9px] translate-x-[-50%] w-[316px]">Open Module</p>
    </div>
  );
}

function Div60() {
  return (
    <div className="absolute bg-white h-[210px] left-[381.33px] rounded-[16px] top-0 w-[357.328px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div59 />
      <P3 />
      <Button9 />
    </div>
  );
}

function PaperPlaneTop1() {
  return (
    <div className="absolute h-[17.778px] left-[calc(50%+0.344px)] top-[calc(50%-0.111px)] translate-x-[-50%] translate-y-[-50%] w-[20px]" data-name="paper-plane-top">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 18">
        <g clipPath="url(#clip0_1_402)" id="paper-plane-top">
          <path d={svgPaths.p1f720500} fill="var(--fill-0, #16A34A)" id="Primary" />
        </g>
        <defs>
          <clipPath id="clip0_1_402">
            <rect fill="white" height="17.7778" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Div61() {
  return (
    <div className="absolute bg-green-50 h-[44px] left-0 rounded-[8px] top-0 w-[40px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <PaperPlaneTop1 />
    </div>
  );
}

function Div62() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-0 top-0 w-[140.578px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div61 />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[52px] not-italic text-[16px] text-slate-800 top-[10px] w-[89px]">AI Dispatch</p>
    </div>
  );
}

function Frame25() {
  return (
    <div className="relative shrink-0 size-[7.5px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
        <g id="Frame">
          <g clipPath="url(#clip0_1_474)">
            <path d={svgPaths.p87dc880} fill="var(--fill-0, #15803D)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_474">
            <path d="M0 0H7.5V7.5H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg22() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[7.5px] top-[3.75px]" data-name="svg">
      <Frame25 />
    </div>
  );
}

function I22() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[16px] left-[8px] top-[2px] w-[7.5px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg22 />
    </div>
  );
}

function Span7() {
  return (
    <div className="absolute bg-green-100 h-[20px] left-[264.31px] rounded-[9999px] top-[12px] w-[51.031px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I22 />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[16px] leading-[normal] left-[19.5px] not-italic text-[12px] text-green-700 top-[2px] w-[37px]">Live</p>
    </div>
  );
}

function Div63() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[44px] left-[21px] top-[21px] w-[315.344px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div62 />
      <Span7 />
    </div>
  );
}

function P4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[40px] left-[21px] top-[77px] w-[315.344px]" data-name="p">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-px w-[316px]">Intelligent dispatch optimization and route</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[14px] text-slate-500 top-[21px] w-[316px]">planning with real-time tracking capabilities.</p>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-slate-100 h-[36px] left-[21px] rounded-[8px] top-[153px] w-[315.344px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[20px] leading-[normal] left-[158px] not-italic text-[14px] text-center text-slate-700 top-[9px] translate-x-[-50%] w-[316px]">Open Module</p>
    </div>
  );
}

function Div64() {
  return (
    <div className="absolute bg-white h-[210px] left-[762.66px] rounded-[16px] top-0 w-[357.344px]" data-name="div">
      <div aria-hidden="true" className="absolute border border-slate-100 border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div63 />
      <P4 />
      <Button10 />
    </div>
  );
}

function Div65() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[210px] left-0 top-[44px] w-[1120px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div56 />
      <Div60 />
      <Div64 />
    </div>
  );
}

function Div66() {
  return (
    <div className="bg-[rgba(0,0,0,0)] h-[254px] relative shrink-0 w-full" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div52 />
      <Div65 />
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[1017px] top-[4px] w-[52.797px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[26.5px] not-italic text-[14px] text-[darkorange] text-center top-px translate-x-[-50%] w-[53px]">View All</p>
    </div>
  );
}

function Div67() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[28px] left-[25px] top-[25px] w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[28px] left-0 not-italic text-[18px] text-gray-900 top-0 w-[133px]">Recent Activity</p>
      <Button11 />
    </div>
  );
}

function Frame26() {
  return (
    <div className="h-[16px] relative shrink-0 w-[14px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_421)">
            <path d={svgPaths.p921bd00} fill="var(--fill-0, #16A34A)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_421">
            <path d="M0 0H14V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg23() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[14px]" data-name="svg">
      <Frame26 />
    </div>
  );
}

function I23() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[13px] top-[8px] w-[14px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg23 />
    </div>
  );
}

function Div68() {
  return (
    <div className="absolute bg-green-100 left-[12px] rounded-[9999px] size-[40px] top-[12px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I23 />
    </div>
  );
}

function Div69() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[68px] top-[14px] w-[599.828px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-gray-900 top-0 w-[600px]">Invoice INV-2024-0847 processed successfully</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 not-italic text-[12px] text-gray-500 top-[20px] w-[600px]">2 minutes ago</p>
    </div>
  );
}

function Span8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[984px] top-[22px] w-[70.172px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-0 not-italic text-[14px] text-green-600 top-px w-[71px]">$2,450.00</p>
    </div>
  );
}

function Div70() {
  return (
    <div className="absolute bg-gray-50 h-[64px] left-0 rounded-[8px] top-0 w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Div68 />
      <Div69 />
      <Span8 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_463)">
            <path d={svgPaths.p803d900} fill="var(--fill-0, #2563EB)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_463">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg24() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[4px]" data-name="svg">
      <Frame27 />
    </div>
  );
}

function I24() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[8px] w-[16px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg24 />
    </div>
  );
}

function Div71() {
  return (
    <div className="absolute bg-blue-100 left-[12px] rounded-[9999px] size-[40px] top-[12px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I24 />
    </div>
  );
}

function Div72() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[68px] top-[14px] w-[602.438px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-gray-900 top-0 w-[603px]">Timesheet batch uploaded by Sarah Johnson</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 not-italic text-[12px] text-gray-500 top-[20px] w-[603px]">15 minutes ago</p>
    </div>
  );
}

function Span9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[986.61px] top-[22px] w-[67.563px]" data-name="span">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-0 not-italic text-[14px] text-blue-600 top-px w-[68px]">24 entries</p>
    </div>
  );
}

function Div73() {
  return (
    <div className="absolute bg-gray-50 h-[64px] left-0 rounded-[8px] top-[80px] w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Div71 />
      <Div72 />
      <Span9 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_399)">
            <path d={svgPaths.p1b500f00} fill="var(--fill-0, #EA580C)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_399">
            <path d="M0 0H16V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg25() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[4px]" data-name="svg">
      <Frame28 />
    </div>
  );
}

function I25() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[24px] left-[12px] top-[8px] w-[16px]" data-name="i">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Svg25 />
    </div>
  );
}

function Div74() {
  return (
    <div className="absolute bg-orange-100 left-[12px] rounded-[9999px] size-[40px] top-[12px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[9999px]" />
      <I25 />
    </div>
  );
}

function Div75() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[36px] left-[68px] top-[14px] w-[621.984px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[20px] left-0 not-italic text-[14px] text-gray-900 top-0 w-[622px]">Anomaly detected in dispatch record DR-2024-1205</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 not-italic text-[12px] text-gray-500 top-[20px] w-[622px]">1 hour ago</p>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[20px] left-[1006.16px] top-[22px] w-[48.016px]" data-name="button">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[24.5px] not-italic text-[14px] text-[darkorange] text-center top-px translate-x-[-50%] w-[49px]">Review</p>
    </div>
  );
}

function Div76() {
  return (
    <div className="absolute bg-gray-50 h-[64px] left-0 rounded-[8px] top-[160px] w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none rounded-[8px]" />
      <Div74 />
      <Div75 />
      <Button12 />
    </div>
  );
}

function Div77() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[224px] left-[25px] top-[77px] w-[1070px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div70 />
      <Div73 />
      <Div76 />
    </div>
  );
}

function Div78() {
  return (
    <div className="bg-white h-[326px] relative rounded-[12px] shrink-0 w-full" data-name="div">
      <div aria-hidden="true" className="absolute border border-gray-200 border-solid inset-0 pointer-events-none rounded-[12px] shadow-[0px_1px_2px_0px_rgba(0,0,0,0.05)]" />
      <Div67 />
      <Div77 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] items-start left-0 top-0 w-[1120px]">
      <Frame7 />
      <Frame6 />
      <Div50 />
      <Div66 />
      <Div78 />
    </div>
  );
}

function Div79() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[1200px] left-[32px] top-[100px] w-[1120px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Frame8 />
    </div>
  );
}

function Main() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[1664px] left-[256px] top-0 w-[1184px]" data-name="main">
      <div className="h-[1664px] overflow-clip relative rounded-[inherit] w-[1184px]">
        <Header />
        <Div79 />
      </div>
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Div80() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] h-[1677px] left-0 top-0 w-[1440px]" data-name="div">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Aside />
      <Main />
    </div>
  );
}

function Body() {
  return (
    <div className="bg-slate-50 h-[1677px] relative shrink-0 w-[1440px]" data-name="body">
      <div aria-hidden="true" className="absolute border-0 border-gray-200 border-solid inset-0 pointer-events-none" />
      <Div80 />
    </div>
  );
}

export default function Option2Dashboard() {
  return (
    <div className="bg-white relative rounded-[8px] size-full" data-name="Option 2 - Dashboard">
      <div className="content-stretch flex flex-col items-start overflow-clip relative rounded-[inherit] size-full">
        <Body />
      </div>
      <div aria-hidden="true" className="absolute border-2 border-[#ced4da] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}